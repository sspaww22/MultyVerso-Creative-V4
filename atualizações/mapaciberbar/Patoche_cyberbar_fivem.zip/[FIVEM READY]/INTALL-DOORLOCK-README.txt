CREDIT : 
Mapping : patoche#4702
Script : DVR#0078
----------------------------------------------------------------------------
----------------------------------------------------------------------------
You want know more about Patoche ? 
- Don't hesitate to join his discord : https://discord.gg/NvrTRdh
& Don't miss something with his youtube chanel : https://www.youtube.com/channel/UCHDmZB2QPSEucvlslURrrqQ
Follow me and up your RP Skill (:p)

You want know more about DVRs'Script ?
- Don't hesitate to join his discord : https://discord.gg/GYjCgcN8hT
& Don't miss his Twitch live here : https://www.twitch.tv/dvr__  

----------------------------------------------------------------------
----------------------- Installation MAPPING : -----------------------


Mapping (folder patoche_cyber_map):
step 1 : Copy/Past the folder " patoche_cyber_map " on your resource folder .
step 2 : Open your server.cfg and Start/Encure patoche_cyber_map.

---------------------------------------------------------------------
----------------------- Installation SCRIPT : -----------------------

Script job bar ( folder DVR_CyberJobBar ) :

/!\ WARNING : The script work with the last ESX version. That use the " weight " and
not the "limit". Take care to show before to try to insert the SQL. 

step 1 : Copy/Past the folder " DVR_CyberJobBar " on your resource folder .
step 2 : Add on your SQL the SQL file " cyberjob " ( it's on the script folder )
step 3 : Open your server.cfg and Start/Encure DVR_CyberJobBar.

More info : 
(EN) "For the purchase of drinks it will be on in a shop you will find the
position in the config.lua. You can edit on the config cloth , car , ... have fun ! DVR"

(FR)"Pour lachats des boissons ce sera sur dans un shop vous trouverez
la position dans le config.lua. Tu peux aussi editer les tenues, voiture,... amuse toi bien ! DVR"
--------------------------------------------------------------------
----------------------- Installation CLOTH : -----------------------
INSTALL :

Cloth : 
Step 1 : Copy/past the files inside the folder " CLOTH " on your Cloths stream folder.
----------------------------------------------------------------------------
----------------------------------------------------------------------------
ADD DOORLOCK  :

place : OUTSIDE DOOR : LEFT
Name of door : patoche_cyber_door3
position : X:310.248 Y:-906.0159 Z:28.31944

place : OUTSIDE DOOR  : RIGHT
Name of door : patoche_cyber_door3
position : X:310.2527 Y:-907.9799 Z:28.31944

place : boss room 
Name of door : patoche_cyber_door4
position : X:324.4915 Y:-925.0674 Z:29.49783

place : stockage : LEFT
Name of door : patoche_cyber_door1
position : X:347.3738 Y:-904.1692 Z:28.24838

place : stockage : RIGHT
Name of door : patoche_cyber_door1
position : X:347.3738 Y:-906.2994 Z:28.24838

place : Entrance one door
Name of door : patoche_cyber_door5
position : X:341.4532 Y:-939.6378 Z:29.56765

----------------------------------------------------------------------------
----------------------------------------------------------------------------

THE TV

IF You use a script who use TV screen for stream : 

Name : prop_tv_flat_01
Position : X:347.1345 Y:-909.6581 Z:29.73359
Position : X:347.1345 Y:-915.9265 Z:29.73359
Position : X:347.1345 Y:-920.0937 Z:29.73359
Position : X:347.1058 Y:-928.6459 Z:29.73056






