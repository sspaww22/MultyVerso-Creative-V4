Hi 
install : copypast the file on your cloth folder.
I find it on 22 tshirt number on my cloth list.