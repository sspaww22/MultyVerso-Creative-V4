[EN ] Hello simple bar script with custom props you just have
to start it in your cfg and put the sql attention this version 
only works with the latest version of ESX and not the 'limit' version 
for the purchase of drinks it will be on in a shop you will find the
position in the config.lua have fun

[FR ] Bonjour simple script de bar avec des props custom vous 
avez juste a le start dans votre cfg et mettre la sql attention 
cette version fontionne que avec la derniere version de ESX et non la version
'limit' pour lachats des boissons ce sera sur dans un shop vous trouverer
la position dans le config.lua amuse toi bien


Discord DVRs'Script : https://discord.gg/GYjCgcN8hT
Twitch : https://www.twitch.tv/dvr__

:)